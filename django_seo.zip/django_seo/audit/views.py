from django.shortcuts import render, redirect

# Create your views here.


from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
import requests
from django.urls import reverse

import requests
from bs4 import BeautifulSoup




def index(request):

	
	if 'domain' not in request.POST:
		#template = loader.get_template('audit/index.html')
		#context = None
		if 'error' in request.GET:
			return render(request, 'audit/index.html', {
		            'error_message': "Podano zły adres.",
		        })
		else:
			return render(request, 'audit/index.html')

			#return HttpResponse(template.render(context,request))
	else:
		url = request.POST['domain']
		print ("To zmienna: ", url)
		try:
			r = requests.get(url)
		except Exception:
			print ("Podano zły adres!")
			return redirect('/audit/?error=True')

		else:
			
			return redirect('/audit/results/?p=%s' %url)

def results(request):


	url = request.GET['p']
	

	r = requests.get(url)
	r_html = r.text


	soup = BeautifulSoup(r_html, 'html.parser')
	title = soup.find('title').string
	print ("Tytuł: %s" %title)
	print ("Tytuł ma długość: %s" %len(title))


	"""

	headings = []

	for x in range(0,9):
		heading = "h"+str(x+1)
		
		#print (heading)
		temp = []
		for y in soup.findAll(heading):
			temp.append(y.text)
		headings.append(temp)
	#print (headings)
	"""

	
	headings = {}
	count = {}

	for x in range(0,9):
		heading = "h"+str(x+1)

		#print (heading)
		headings_list = []
		temp=0
		for y in soup.findAll(heading):
			headings_list.append(y.text)
			temp+=1
		headings[heading.upper()] = headings_list
		count[heading.upper()]=temp
	#print (headings)


	for x in headings:
		print ('\n%s - ' %x + str(len(headings[x])) + '\n')

		for y in headings[x]:
			print (y)
	
		#print ("\n\n%s\n\n" %x)
		#print ([y for y in headings[x]])


	return render(request, 'audit/results.html', {'url': url,'headings': headings, 'title': title, 'characters': len(title), 'count': count})


	#return HttpResponse(url)
	#return HttpResponseRedirect(reverse('audit:results' %url, args=None ))
	#return HttpResponse(request.POST['domain'])