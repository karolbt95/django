import requests


print("Hello world")

x = requests.get(url)
print(x.status_code)

