from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login
from django.contrib.auth import logout

def index(request):

	


	if 'submit' in request.POST:
		username = request.POST['uname']
		password = request.POST['psw']
		user = authenticate(request, username=username, password=password)
		if user is not None:
			login(request, user)
			return redirect('/')
		else:
			return render(request, 'login/index.html', {'error_message':'Podano błędne dane! Spróbuj ponownie.'})

	else:

		if not request.user.is_authenticated:
			return render(request, 'login/index.html')
		else:
			return render(request, 'login/index.html', {'logged':True})
			#return redirect('/')

def logout_view(request):
    logout(request)
    return redirect('/login/')
