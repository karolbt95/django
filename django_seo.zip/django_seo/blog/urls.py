from django.urls import path

from . import views

app_name = 'blog'
urlpatterns = [
    path('', views.index, name='index'),
    path('categories/', views.all_categories, name='all_categories'),
	path('<int:category_id>/category/', views.category, name='category'),
	path('<int:text_id>/text/', views.text, name='text'),
	path('addcategory/', views.addcategory, name='addcategory'),
	path('addtext/', views.addtext, name='addtext'),
	
]