from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Category, Text
from django.shortcuts import get_object_or_404, render
from django.utils import timezone
from django.contrib.auth.decorators import permission_required, login_required


# Create your views here.


def index(request):

	texts = Text.objects.order_by('-pub_date')[:6]
	#output = ', '.join([q.title for q in texts])
	#return HttpResponse(output)

	#return render(request, 'database/index.html', {'test':'test'})


	return render(request, 'blog/index.html', {'texts': texts})


def all_categories(request):

	categories = Category.objects.order_by('pk')[:6]

	return render(request, 'blog/categories.html', {'categories': categories})


def category(request, category_id):
	"""
	try:
		text = Text.objects(category=category_id)
	except Text.DoesNotExist:
		raise Http404("Kategoria nie isnieje")
	return render(request, 'blog/category.html', {'text': text})
	"""

	category = Category.objects.get(pk=category_id)
	texts = Text.objects.filter(category=category_id)

	#text = get_object_or_404(Text, category=category_id)
	return render(request, 'blog/category.html', {'texts': texts, 'category':category})

def text(request, text_id):

	text = Text.objects.get(pk=text_id)

	return render(request, 'blog/text.html', {'text': text})


@login_required(login_url='/login/')
@permission_required('blog.add_category', login_url='/login/')
def addcategory(request):



	if 'submit' not in request.POST:
		#template = loader.get_template('audit/index.html')
		#context = None
		if 'status' in request.GET:
			if request.GET['status']=='error':

				return render(request, 'blog/addcategory.html', {
			            'error_message': "Nie wypełniono wszystkich pól.",
			        })
			elif request.GET['status']=='success':
				return render(request, 'blog/addcategory.html', {
			            'success_message': "Udało się.",
			        })

		else:
			return render(request, 'blog/addcategory.html')

			#return HttpResponse(template.render(context,request))
	else:
		category = request.POST['category']
		print ("To zmienna: ", category)
		if category=='':
			return redirect('/blog/addcategory/?status=error')

		else:
			from blog.models import Category
			add = Category(name=category)
			add.save()

			return redirect('/blog/addcategory/?status=success')

@login_required(login_url='/login/')
@permission_required('blog.add_text', login_url='/login/')
def addtext(request):

	categories = Category.objects.order_by('pk')[:6]


	if 'submit' not in request.POST:
		#template = loader.get_template('audit/index.html')
		#context = None
		if 'status' in request.GET:
			if request.GET['status']=='error':

				return render(request, 'blog/addtext.html', {
			            'error_message': "Nie wypełniono wszystkich pól.",
			            'categories': categories
			        })
			elif request.GET['status']=='success':
				return render(request, 'blog/addtext.html', {
			            'success_message': "Udało się.",
			            'categories': categories
			        })

		else:
			return render(request, 'blog/addtext.html', {'categories': categories})

			#return HttpResponse(template.render(context,request))
	else:
		category_id = request.POST['category']
		title = request.POST['title']
		meta_title = request.POST['meta_title']
		text = request.POST['text']

		#category = get_object_or_404(Category, pk=category_id)
		category = Category.objects.get(pk=category_id)
		pub_date = timezone.now()

		

		print(category_id)
		print(title)
		print(meta_title)
		print(text)
		
		if category=='' or title=='' or meta_title=='' or text=='':
			return redirect('/blog/addtext/?status=error')

		else:
			from blog.models import Text
			add = Text(category=category, text=text, title=title, meta_title=meta_title, pub_date=pub_date)
			add.save()

			return redirect('/blog/addtext/?status=success')



	"""
	if 'submit' not in request.POST:

		return render(request, 'blog/addtext.html', {'categories':categories})

	else:
		return redirect('/blog/addtext/?status=test')
	"""